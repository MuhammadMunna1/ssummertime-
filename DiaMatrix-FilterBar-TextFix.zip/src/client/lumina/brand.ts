/**
 * DiaMatrix — product branding
 * Use these constants everywhere so naming stays consistent.
 */
export const BRAND = {
  /** Full product name */
  full: 'DiaMatrix',
  /** Short product name (UI chrome, tabs, badges) */
  short: 'DiaMatrix',
  /** Company legal / footer */
  company: 'Diamond World LTD',
  /** Tagline */
  tagline: 'The Intelligent Distribution Engine for Precious Assets',
  /** Legacy house line */
  houseLine: 'precious assets intelligence',
  /** Console / desktop label */
  console: 'DiaMatrix Desktop Console',
  /** AI assistant label */
  aiName: 'DiaMatrix AI',
  /** Live status chip */
  liveStatus: 'LIVE · DIAMATRIX',
  /** Product version */
  version: '2.0.0',
  /** Build channel */
  channel: 'Production',
} as const;

export type BrandKeys = typeof BRAND;
