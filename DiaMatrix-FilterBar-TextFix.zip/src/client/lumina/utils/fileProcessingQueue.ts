import type { ParsedDataResult, UploadFileBlob } from './universalParser';

export type MergeJob = {
  stockFiles: UploadFileBlob[];
  soldFiles: UploadFileBlob[];
};

let worker: Worker | null = null;
let sequence = 0;
const pending = new Map<number, { resolve: (value: ParsedDataResult) => void; reject: (reason?: unknown) => void }>();

function getWorker(): Worker {
  if (worker) return worker;
  worker = new Worker(new URL('./fileProcessingWorker.ts', import.meta.url), { type: 'module' });
  worker.onmessage = (event: MessageEvent) => {
    const { id, ok, result, error } = event.data || {};
    const task = pending.get(id);
    if (!task) return;
    pending.delete(id);
    if (ok) task.resolve(result as ParsedDataResult);
    else task.reject(new Error(error || 'Background file processing failed'));
  };
  worker.onerror = (event) => {
    const error = new Error(event.message || 'Background file processing worker failed');
    for (const task of pending.values()) task.reject(error);
    pending.clear();
    worker?.terminate();
    worker = null;
  };
  return worker;
}

function cloneForWorker(files: UploadFileBlob[]): UploadFileBlob[] {
  return files.map(file => ({
    ...file,
    content: file.content instanceof ArrayBuffer ? file.content.slice(0) : file.content,
  }));
}

function transferables(job: MergeJob): Transferable[] {
  return [...job.stockFiles, ...job.soldFiles]
    .map(file => file.content)
    .filter((content): content is ArrayBuffer => content instanceof ArrayBuffer);
}

/**
 * Background merge queue. The worker keeps XLSX/CSV parsing off the React main
 * thread, while preserving a synchronous fallback for environments that do not
 * support module workers (older embedded previews/tests).
 */
export function queueBackgroundMerge(job: MergeJob): Promise<ParsedDataResult> {
  if (typeof Worker === 'undefined') {
    return import('./universalParser').then(({ mergeDualStockAndSoldData, mergeMultiFileStockAndSoldData }) =>
      job.stockFiles.length === 1 && job.soldFiles.length === 1
        ? mergeDualStockAndSoldData(job.stockFiles[0].content, job.soldFiles[0].content, job.stockFiles[0].name, job.soldFiles[0].name)
        : mergeMultiFileStockAndSoldData(job.stockFiles, job.soldFiles)
    );
  }

  const id = ++sequence;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    try {
      const payload = {
        id,
        stockFiles: cloneForWorker(job.stockFiles),
        soldFiles: cloneForWorker(job.soldFiles),
      };
      getWorker().postMessage(payload, transferables(payload));
    } catch (error) {
      pending.delete(id);
      reject(error);
    }
  });
}
