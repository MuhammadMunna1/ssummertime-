/**
 * IndexedDB permanent store for Diamatrix inventory.
 * Survives browser restarts — no re-upload needed; append new daily files.
 */

import { RawInventoryRecord } from '../types';
import type { DailyInventorySnapshot } from './dailyStorageEngine';

const DB_NAME = 'diamatrix_inventory_db';
const DB_VERSION = 1;
const STORE_META = 'meta';
const STORE_RECORDS = 'records';
const STORE_SNAPSHOTS = 'snapshots';

const META_WORKING = 'working_dataset';
const LS_SNAPSHOT_KEY = 'oracle_retail_daily_snapshots_v2';
const LS_WORKING_KEY = 'diamatrix_working_records_v1';

export type ImportMode = 'replace' | 'append';

export interface WorkingDatasetMeta {
  id: typeof META_WORKING;
  updatedAt: number;
  label: string;
  period?: string;
  recordCount: number;
  totalStock: number;
  totalSold: number;
  branchesCount: number;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not available'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error || new Error('IDB open failed'));
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_RECORDS)) {
        const store = db.createObjectStore(STORE_RECORDS, { keyPath: 'id' });
        store.createIndex('by_branch', 'branch', { unique: false });
        store.createIndex('by_weight', 'weight', { unique: false });
        store.createIndex('by_key', 'mergeKey', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) {
        const snap = db.createObjectStore(STORE_SNAPSHOTS, { keyPath: 'id' });
        snap.createIndex('by_date', 'date', { unique: false });
        snap.createIndex('by_ts', 'timestamp', { unique: false });
      }
    };
  });
}

function idbReq<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('aborted'));
  });
}

/** Stable merge key: branch + weight + design/item */
export function recordMergeKey(r: RawInventoryRecord): string {
  const design = (r.itemCode || r.itemName || r.variant || '').trim().toLowerCase();
  return `${(r.branch || '').trim().toLowerCase()}||${(r.weight || '').trim()}||${design}`;
}

export interface StoredRecord extends RawInventoryRecord {
  mergeKey: string;
}

function toStored(r: RawInventoryRecord): StoredRecord {
  return {
    ...r,
    id: r.id || `rec-${recordMergeKey(r)}-${Date.now()}`,
    mergeKey: recordMergeKey(r),
  };
}

/**
 * Append semantics:
 * - Same branch+weight+design → update stock/sold (prefer newer non-zero / sum sold, replace stock)
 * - New keys → insert
 */
export function mergeRecordsAppend(
  existing: RawInventoryRecord[],
  incoming: RawInventoryRecord[]
): RawInventoryRecord[] {
  const map = new Map<string, RawInventoryRecord>();
  for (const r of existing) {
    map.set(recordMergeKey(r), { ...r });
  }
  for (const r of incoming) {
    const key = recordMergeKey(r);
    const prev = map.get(key);
    if (!prev) {
      map.set(key, { ...r, id: r.id || `rec-${key}-${Date.now()}` });
      continue;
    }
    // Stock: take latest upload as current on-hand
    // Sold: accumulate period sales when appending daily files
    map.set(key, {
      ...prev,
      ...r,
      id: prev.id,
      currentStock: r.currentStock ?? prev.currentStock,
      soldQty: (prev.soldQty || 0) + (r.soldQty || 0),
      sales3M: r.sales3M ?? prev.sales3M,
      sales6M: r.sales6M ?? prev.sales6M,
      sales1Y: r.sales1Y ?? prev.sales1Y,
      sales2Y: r.sales2Y ?? prev.sales2Y,
      category: r.category || prev.category,
      itemCode: r.itemCode || prev.itemCode,
      itemName: r.itemName || prev.itemName,
      variant: r.variant || prev.variant,
    });
  }
  return Array.from(map.values());
}

export async function saveWorkingDataset(
  records: RawInventoryRecord[],
  opts?: { label?: string; period?: string; mode?: ImportMode }
): Promise<WorkingDatasetMeta> {
  const mode = opts?.mode || 'replace';
  let final = records;

  if (mode === 'append') {
    const current = await loadWorkingRecords();
    final = mergeRecordsAppend(current, records);
  }

  const stored = final.map(toStored);
  const totalStock = stored.reduce((s, r) => s + (r.currentStock || 0), 0);
  const totalSold = stored.reduce((s, r) => s + (r.soldQty || 0), 0);
  const branches = new Set(stored.map((r) => r.branch));

  const meta: WorkingDatasetMeta = {
    id: META_WORKING,
    updatedAt: Date.now(),
    label: opts?.label || `Working dataset · ${stored.length} rows`,
    period: opts?.period,
    recordCount: stored.length,
    totalStock,
    totalSold,
    branchesCount: branches.size,
  };

  const db = await openDb();
  try {
    const tx = db.transaction([STORE_META, STORE_RECORDS], 'readwrite');
    const recStore = tx.objectStore(STORE_RECORDS);
    const metaStore = tx.objectStore(STORE_META);

    // Clear + bulk put for replace path; for append we already merged in memory
    await idbReq(recStore.clear());
    for (const r of stored) {
      recStore.put(r);
    }
    metaStore.put(meta);
    await txDone(tx);

    // Mirror small meta to localStorage for quick boot flag
    try {
      localStorage.setItem(
        LS_WORKING_KEY,
        JSON.stringify({
          updatedAt: meta.updatedAt,
          recordCount: meta.recordCount,
          label: meta.label,
          period: meta.period,
        })
      );
    } catch {
      /* ignore */
    }

    return meta;
  } finally {
    db.close();
  }
}

export async function loadWorkingRecords(): Promise<RawInventoryRecord[]> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_RECORDS, 'readonly');
      const all = await idbReq(tx.objectStore(STORE_RECORDS).getAll());
      await txDone(tx);
      return (all || []).map(({ mergeKey, ...rest }) => rest as RawInventoryRecord);
    } finally {
      db.close();
    }
  } catch (e) {
    console.warn('IndexedDB load failed, empty set', e);
    return [];
  }
}

export async function loadWorkingMeta(): Promise<WorkingDatasetMeta | null> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_META, 'readonly');
      const meta = await idbReq(tx.objectStore(STORE_META).get(META_WORKING));
      await txDone(tx);
      return (meta as WorkingDatasetMeta) || null;
    } finally {
      db.close();
    }
  } catch {
    return null;
  }
}

export async function clearWorkingDataset(): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction([STORE_META, STORE_RECORDS], 'readwrite');
    tx.objectStore(STORE_RECORDS).clear();
    tx.objectStore(STORE_META).delete(META_WORKING);
    await txDone(tx);
    try {
      localStorage.removeItem(LS_WORKING_KEY);
    } catch {
      /* ignore */
    }
  } finally {
    db.close();
  }
}

export async function saveSnapshotToIdb(snapshot: DailyInventorySnapshot): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE_SNAPSHOTS, 'readwrite');
    tx.objectStore(STORE_SNAPSHOTS).put(snapshot);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function getSnapshotsFromIdb(): Promise<DailyInventorySnapshot[]> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_SNAPSHOTS, 'readonly');
      const all = await idbReq(tx.objectStore(STORE_SNAPSHOTS).getAll());
      await txDone(tx);
      return (all || []).sort(
        (a: DailyInventorySnapshot, b: DailyInventorySnapshot) => b.timestamp - a.timestamp
      );
    } finally {
      db.close();
    }
  } catch {
    return [];
  }
}

export async function deleteSnapshotFromIdb(id: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE_SNAPSHOTS, 'readwrite');
    tx.objectStore(STORE_SNAPSHOTS).delete(id);
    await txDone(tx);
  } finally {
    db.close();
  }
}

/**
 * One-time migration: localStorage snapshots → IndexedDB + seed working set from latest snap.
 */
export async function migrateLocalStorageToIdb(): Promise<{
  migratedSnapshots: number;
  seededWorking: boolean;
}> {
  let migratedSnapshots = 0;
  let seededWorking = false;

  try {
    const raw = localStorage.getItem(LS_SNAPSHOT_KEY);
    if (raw) {
      const list = JSON.parse(raw) as DailyInventorySnapshot[];
      if (Array.isArray(list) && list.length) {
        for (const snap of list) {
          await saveSnapshotToIdb(snap);
          migratedSnapshots++;
        }
        const existing = await loadWorkingRecords();
        if (existing.length === 0 && list[0]?.records?.length) {
          await saveWorkingDataset(list[0].records, {
            label: list[0].label || 'Migrated from localStorage',
            mode: 'replace',
          });
          seededWorking = true;
        }
      }
    }
  } catch (e) {
    console.warn('LS→IDB migration partial fail', e);
  }

  return { migratedSnapshots, seededWorking };
}

/** Boot helper: migrate if needed, return working records */
export async function bootstrapInventoryFromIdb(): Promise<{
  records: RawInventoryRecord[];
  meta: WorkingDatasetMeta | null;
}> {
  await migrateLocalStorageToIdb();
  const meta = await loadWorkingMeta();
  const records = await loadWorkingRecords();
  return { records, meta };
}
