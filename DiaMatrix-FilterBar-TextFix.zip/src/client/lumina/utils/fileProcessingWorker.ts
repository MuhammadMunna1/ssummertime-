import { mergeDualStockAndSoldData, mergeMultiFileStockAndSoldData, type UploadFileBlob } from './universalParser';

self.onmessage = (event: MessageEvent) => {
  const { id, stockFiles, soldFiles } = event.data as {
    id: number;
    stockFiles: UploadFileBlob[];
    soldFiles: UploadFileBlob[];
  };
  try {
    const result = stockFiles.length === 1 && soldFiles.length === 1
      ? mergeDualStockAndSoldData(stockFiles[0].content, soldFiles[0].content, stockFiles[0].name, soldFiles[0].name)
      : mergeMultiFileStockAndSoldData(stockFiles, soldFiles);
    self.postMessage({ id, ok: true, result });
  } catch (error) {
    self.postMessage({ id, ok: false, error: error instanceof Error ? error.message : String(error) });
  }
};
