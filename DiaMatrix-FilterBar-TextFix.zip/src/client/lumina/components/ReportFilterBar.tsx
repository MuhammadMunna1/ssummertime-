import React, { useMemo, useState, useEffect } from 'react';
import {
  Building2,
  Gem,
  Filter,
  X,
  Search,
  Layers,
  ChevronDown,
  ChevronUp,
  Settings2,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';

export interface ReportFilters {
  branchId: string;
  ctsFrom: string;
  ctsTo: string;
  mainCategory: string;
  subCategory: string;
}

interface ReportFilterBarProps {
  rawRecords: RawInventoryRecord[];
  filters: ReportFilters;
  onFiltersChange: (f: ReportFilters) => void;
  filteredCount: number;
  totalCount: number;
}

/** Parse weight/carat string to number (also Oracle range codes K30→0.30, L01→1.01) */
export function parseCaratValue(weight: string): number | null {
  if (!weight) return null;
  // Support composite keys "0.05 · NP7SD1" or "K30 · DESIGN"
  const base = String(weight).split('·')[0].trim();
  // Oracle range codes
  const range = base.match(/^([A-Za-z])(\d{2,3})$/);
  if (range) {
    const letter = range[1].toUpperCase();
    const digits = parseInt(range[2], 10);
    if (!isNaN(digits)) {
      if (letter === 'K') return digits / 100;
      if (letter === 'L') return 1 + digits / 100;
      return letter.charCodeAt(0) - 64 + digits / 1000;
    }
  }
  const cleaned = base.replace(/[^\d.]/g, '');
  const n = parseFloat(cleaned);
  return isNaN(n) ? null : n;
}

const isWarehouseBranchName = (branch: string) => {
  const lower = (branch || '').toLowerCase().trim();
  return (
    lower === 'dwl' ||
    lower.startsWith('dwl ') ||
    lower.endsWith(' dwl') ||
    lower.includes('warehouse') ||
    lower.includes('central') ||
    lower.includes('hub')
  );
};

export function applyReportFilters(
  records: RawInventoryRecord[],
  filters: ReportFilters
): RawInventoryRecord[] {
  const fromRaw = filters.ctsFrom.trim();
  const toRaw = filters.ctsTo.trim();
  // Parse both decimal (0.30) and Oracle range codes (K30 → 0.30, L01 → 1.01)
  const fromN = fromRaw !== '' ? parseCaratValue(fromRaw) : null;
  const toN = toRaw !== '' ? parseCaratValue(toRaw) : null;
  const branchQ = filters.branchId.trim().toLowerCase();
  const mainCat = filters.mainCategory.trim().toLowerCase();
  const subCat = filters.subCategory.trim().toLowerCase();

  return records.filter((r) => {
    const isWh = isWarehouseBranchName(r.branch);

    if (branchQ) {
      const b = (r.branch || '').toLowerCase().trim();
      const q = branchQ.trim();
      // Special: exact trailing-S search (mohs, bcts) → only that individual outlet
      const isExactS = /^[a-z]{2,4}s$/.test(q) && q !== 'dwl' && q !== 'onl' && q !== 'whl';
      if (isExactS) {
        if (!isWh && b !== q) return false;
      } else {
        // Parent code (moh, bct): match parent AND its S variant (moh + mohs)
        const parent = q.replace(/s$/, '');
        const matchesFamily =
          b === q ||
          b === q + 's' ||
          (parent.length >= 2 && (b === parent || b === parent + 's')) ||
          b.includes(q);
        if (!isWh && !matchesFamily) return false;
      }
    }

    // Range / Cts From–To filter
    if (fromRaw || toRaw) {
      const w = parseCaratValue(r.weight);
      const weightKey = String(r.weight || '')
        .toUpperCase()
        .split('·')[0]
        .trim();

      if (w != null && (fromN != null || toN != null)) {
        // Numeric compare (works for 0.30 cents AND K30/L01 range codes)
        if (fromN != null && w < fromN - 1e-9) return false;
        if (toN != null && w > toN + 1e-9) return false;
      } else if (w == null) {
        // Non-numeric weight keys: alphabetical range on the code itself
        const fromKey = fromRaw.toUpperCase();
        const toKey = toRaw.toUpperCase();
        if (fromKey && weightKey < fromKey) return false;
        if (toKey && weightKey > toKey) return false;
      } else if (fromN == null && fromRaw) {
        // User typed a code we couldn't parse numerically — exact/prefix match on key
        if (!weightKey.startsWith(fromRaw.toUpperCase()) && weightKey !== fromRaw.toUpperCase()) {
          // also try: if only "from" set without numeric value, keep keys >= text
          if (weightKey < fromRaw.toUpperCase()) return false;
        }
      }
    }

    if (mainCat) {
      const c = `${r.category || ''} ${r.itemName || ''}`.toLowerCase();
      if (!c.includes(mainCat)) return false;
    }

    if (subCat) {
      // Exact design/style code match only (NP7SD1 must NOT match NP7SD10)
      // Also match composite weight keys like "0.08 · NP7SD1"
      const code = (r.itemCode || r.variant || '').toLowerCase().trim();
      const weightDesign = String(r.weight || '')
        .toLowerCase()
        .split('·')
        .map((p) => p.trim())
        .filter(Boolean);
      const designFromWeight = weightDesign.length >= 2 ? weightDesign.slice(1).join(' · ') : '';
      const exactCode =
        code === subCat ||
        designFromWeight === subCat ||
        (r.variant || '').toLowerCase().trim() === subCat ||
        (r.itemCode || '').toLowerCase().trim() === subCat;
      if (!exactCode) {
        // Fallback: whole-token match inside itemName (word boundary style)
        const hay = `${r.itemName || ''}`.toLowerCase();
        const tokenRe = new RegExp(
          `(^|[^a-z0-9])${subCat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`
        );
        if (!tokenRe.test(hay)) return false;
      }
    }

    return true;
  });
}

export const EMPTY_FILTERS: ReportFilters = {
  branchId: '',
  ctsFrom: '',
  ctsTo: '',
  mainCategory: '',
  subCategory: '',
};

const fieldCls =
  'h-9 w-full rounded-lg border border-slate-200/80 bg-white/90 px-3 text-[12px] font-bold text-slate-900 placeholder:text-slate-500 shadow-[inset_0_2px_4px_rgba(0,0,0,0.06)] focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-200 transition-all caret-slate-900';

/**
 * SAP Fiori–style filter bar:
 * compact fields, Go / Adapt Filters / Clear, active filter chips
 */
export const ReportFilterBar: React.FC<ReportFilterBarProps> = ({
  rawRecords,
  filters,
  onFiltersChange,
  filteredCount,
  totalCount,
}) => {
  const [draft, setDraft] = useState<ReportFilters>(filters);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    setDraft(filters);
  }, [filters]);

  const branchOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.branch) set.add(r.branch);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.category) set.add(r.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const caratOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.weight) {
        const base = String(r.weight).split('·')[0].trim();
        if (base) set.add(base);
      }
    });
    return Array.from(set).sort((a, b) => {
      const na = parseFloat(a);
      const nb = parseFloat(b);
      if (!isNaN(na) && !isNaN(nb)) return na - nb;
      return a.localeCompare(b);
    });
  }, [rawRecords]);

  const styleOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.itemCode) set.add(r.itemCode);
      if (r.variant) set.add(r.variant);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b)).slice(0, 300);
  }, [rawRecords]);

  const activeChips: { key: keyof ReportFilters; label: string }[] = [];
  if (filters.branchId) activeChips.push({ key: 'branchId', label: `Branch: ${filters.branchId}` });
  if (filters.ctsFrom || filters.ctsTo) {
    activeChips.push({
      key: 'ctsFrom',
      label: `Range: ${filters.ctsFrom || '…'} – ${filters.ctsTo || '…'}`,
    });
  }
  if (filters.mainCategory) activeChips.push({ key: 'mainCategory', label: `Category: ${filters.mainCategory}` });
  if (filters.subCategory) activeChips.push({ key: 'subCategory', label: `Design: ${filters.subCategory}` });

  const hasActive = activeChips.length > 0;

  const handleGo = () => onFiltersChange({ ...draft });

  const handleClear = () => {
    setDraft(EMPTY_FILTERS);
    onFiltersChange(EMPTY_FILTERS);
  };

  const removeChip = (key: keyof ReportFilters) => {
    const next = { ...filters };
    if (key === 'ctsFrom') {
      next.ctsFrom = '';
      next.ctsTo = '';
    } else {
      next[key] = '';
    }
    setDraft(next);
    onFiltersChange(next);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleGo();
  };

  return (
    <div
      id="sap-filter-bar"
      data-filter-bar="true"
      className="rounded-2xl border border-white/30 bg-white/70 backdrop-blur-md text-slate-800 shadow-lg overflow-hidden"
      role="search"
      aria-label="SAP-style filter bar"
    >
      {/* Header strip */}
      <div className="h-[36px] flex items-center justify-between px-4 border-b border-slate-200/60 bg-white/40">
        <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-800">
          <Filter className="w-3.5 h-3.5 text-cyan-600" />
          <span>Filter</span>
          <span className="font-semibold text-slate-500">
            · {filteredCount.toLocaleString()} of {totalCount.toLocaleString()}
            {hasActive ? ' (filtered)' : ''}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-600 hover:text-cyan-700 hover:underline h-8 px-1 transition-colors"
        >
          <Settings2 className="w-3 h-3" />
          Adapt Filters
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* Primary filter row — always visible (SAP compact) */}
      <div className="min-h-[68px] px-4 py-2.5 flex flex-wrap items-end gap-x-3.5 gap-y-2 bg-transparent">
        {/* Branch */}
        <div className="min-w-[120px] flex-1 max-w-[180px]">
          <label className="block text-[11px] font-bold text-slate-700 mb-1 leading-[14px]">
            <Building2 className="w-3 h-3 inline mr-0.5 text-cyan-600" />
            Branch
          </label>
          <input
            type="text"
            list="sap-branch-options"
            value={draft.branchId}
            onChange={(e) => setDraft({ ...draft, branchId: e.target.value })}
            onKeyDown={onKey}
            placeholder="All"
            className={fieldCls}
          />
          <datalist id="sap-branch-options">
            {branchOptions.map((b) => (
              <option key={b} value={b} />
            ))}
          </datalist>
        </div>

        {/* Range / Cts From — works for 0.02 cents OR K30 range codes */}
        <div className="min-w-[90px] w-[110px]">
          <label className="block text-[11px] font-bold text-slate-700 mb-1 leading-[14px]">
            <Gem className="w-3 h-3 inline mr-0.5 text-cyan-500" />
            Range / Cts From
          </label>
          <input
            type="text"
            list="sap-cts-from"
            value={draft.ctsFrom}
            onChange={(e) => setDraft({ ...draft, ctsFrom: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.02 or K30"
            className={fieldCls}
          />
          <datalist id="sap-cts-from">
            {caratOptions.map((c) => (
              <option key={`f-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Range / Cts To */}
        <div className="min-w-[90px] w-[110px]">
          <label className="block text-[11px] font-bold text-slate-700 mb-1 leading-[14px]">Range / Cts To</label>
          <input
            type="text"
            list="sap-cts-to"
            value={draft.ctsTo}
            onChange={(e) => setDraft({ ...draft, ctsTo: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.20 or L10"
            className={fieldCls}
          />
          <datalist id="sap-cts-to">
            {caratOptions.map((c) => (
              <option key={`t-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Category */}
        <div className="min-w-[140px] flex-1 max-w-[220px]">
          <label className="block text-[11px] font-bold text-slate-700 mb-1 leading-[14px]">
            <Layers className="w-3 h-3 inline mr-0.5 text-cyan-500" />
            Category
          </label>
          <input
            type="text"
            list="sap-cat-options"
            value={draft.mainCategory}
            onChange={(e) => setDraft({ ...draft, mainCategory: e.target.value })}
            onKeyDown={onKey}
            placeholder="All categories"
            className={fieldCls}
          />
          <datalist id="sap-cat-options">
            {categoryOptions.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </div>

        {/* Style / Design / Sub-category — exact match for codes */}
        <div className="min-w-[140px] flex-1 max-w-[220px]">
          <label className="block text-[11px] font-bold text-slate-700 mb-1 leading-[14px]">
            <Gem className="w-3 h-3 inline mr-0.5 text-cyan-500" />
            Design / Sub-Cat
          </label>
          <input
            type="text"
            list="sap-style-options"
            value={draft.subCategory}
            onChange={(e) => setDraft({ ...draft, subCategory: e.target.value })}
            onKeyDown={onKey}
            placeholder="NP7SD1 or sub-cat…"
            className={fieldCls}
          />
          <datalist id="sap-style-options">
            {styleOptions.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5 pb-0.5">
          <button
            type="button"
            onClick={handleGo}
            className="h-9 min-w-[70px] px-3.5 bg-gradient-to-b from-cyan-500 to-cyan-600 text-white text-[12px] font-bold border-b-4 border-cyan-700 rounded-lg inline-flex items-center justify-center gap-1.5 shadow-md active:translate-y-[2px] active:border-b-0 transition-all hover:from-cyan-400 hover:to-cyan-500"
          >
            <Search className="w-3.5 h-3.5" />
            Go
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={!hasActive && !draft.branchId && !draft.ctsFrom && !draft.ctsTo && !draft.mainCategory && !draft.subCategory}
            className="h-9 min-w-[73px] px-3.5 bg-white/50 border border-slate-300 text-[12px] font-bold text-slate-700 hover:bg-white/80 disabled:opacity-40 inline-flex items-center justify-center gap-1 rounded-lg transition-all"
          >
            <X className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      {/* Adapted / secondary filters */}
      {expanded && (
        <div className="px-3 pb-2 flex flex-wrap items-end gap-x-3 gap-y-2 border-t border-slate-200/60 pt-2 bg-white/30">
          <p className="text-[10px] text-slate-600 max-w-lg leading-snug self-center">
            <strong>Design Name</strong> খালি রাখলে → main category (যেমন Nosepin 7 Stone) carat-wise stock &amp; sales রিপোর্ট।
            Design code লিখে Go চাপলে → শুধু সেই design-এর breakdown রিপোর্ট (NP7SD1, NP7SD2…)।
          </p>
        </div>
      )}

      {/* Active filter chips */}
      {hasActive && (
        <div className="px-3 py-1.5 border-t border-slate-200/60 bg-white/40 flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-semibold text-slate-500 mr-1">Active:</span>
          {activeChips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => removeChip(chip.key)}
              className="inline-flex items-center gap-1 h-6 px-2 text-[11px] bg-cyan-50 text-cyan-800 border border-cyan-200 rounded-md hover:bg-cyan-100 transition-colors"
              title="Remove filter"
            >
              {chip.label}
              <X className="w-3 h-3" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
